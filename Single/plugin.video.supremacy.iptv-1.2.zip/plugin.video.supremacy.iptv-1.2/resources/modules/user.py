import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnN1YmxpbWU=')

name = b.b64decode('U3VibGltZQ==')

host = b.b64decode('aHR0cDovL3JlZHR2LmNm')
port = b.b64decode('ODA4MA==')